import 'package:get/get.dart';

class LocationPermissionController extends GetxController {
  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
  }
}
