import 'package:get/get.dart';

class AddressAddController extends GetxController{

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
  }
}