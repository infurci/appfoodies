const Map<String, String> trFR = {};
